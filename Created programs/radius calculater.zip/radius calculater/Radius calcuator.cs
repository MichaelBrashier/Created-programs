﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace radius_calculater
{
    class Program
    {
        
        static double CalculateArea(double dRadius) {
            const double PI = 3.1459265;
            double dArea;

            dArea = PI * (dRadius * dRadius);

            return dArea; 


        }





        static void Main(string[] args)
        {
            // Declare variables
          
            double dArea;
            double dRadius;

            //input from user
            Console.WriteLine("please enter the radius");
            dRadius = double.Parse(Console.ReadLine());

            dArea = PI * (dRadius * dRadius);

            Console.WriteLine("the area of the circle is");
            Console.WriteLine(dArea);

            Console.ReadLine();
        }
        
    }
}
