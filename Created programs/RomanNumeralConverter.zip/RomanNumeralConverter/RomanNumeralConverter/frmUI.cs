﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RomanNumeralConverter
{
    public partial class frmUI : Form
    {
        // Declare variables for storing and parsing Roman Numeral
        String romanNumeral = "";
        Context rnContext;

        // Declare a variable to store expression tree
        List<Expression> rnExpressionTree;
        public frmUI()
        {
            InitializeComponent();
        }

        private void ExitApplication()
        {
            // Procedure for exiting the application
            // 1. Prompt user for exit
            // Declare variables for user exit prompt
            String exitMessage = "Are you sure you want to exit?";
            String exitCaption = "Exit Application?";
            // Declare variable to store user's response
            DialogResult userChoice;
            // Display message box prompting user for exit
            userChoice = MessageBox.Show(exitMessage, exitCaption,
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            // 2. Validate user's choice
            // Use an if statement to determine which button was pressed
            if (userChoice.Equals(DialogResult.Yes))
            {
                // User clicked yes button
                // 3. Exit application
                Application.Exit();
            }
        }

        private void ResetForm()
        {
            // Reset the form by clearing input and output
            // Clear input textbox
            txtInput.Text = "";
            // Clear output label
            txtOutput.Text = "";

            // Clear romanNumeral value
            romanNumeral = "";

            // Reset context
            rnContext = null;
            rnExpressionTree = null;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //call the ExitApplication() procedure
            ExitAppliacation ();
        }


        // ExitApllication procedure
        private void ExitApplication()
        {
            //prompt for exit
            DialogResult userChoice = MessageBox.Show("Are you sure you want to leave" , "Exit apllication" , MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            //Check which button the user clicked
            if(userChoice.Equals(DialogResult.Yes))
            {
                //User clicked yes, exit application
                Application.Exit();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //Prompt user to reset

            //prompt for exit
            DialogResult userChoice = MessageBox.Show("Are you sure you want to reset the form", "Exit apllication", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            //Check which button the user clicked
            if (userChoice.Equals(DialogResult.Yes))
            {
                //call the reset procedure
                Reset();
            }
         
        }

        //Reset procedure
        private void Reset()
        {
            // Reset form by clearing input and output
            txtInput.Text = "";
            txtOutput.Text = "";

            //clear romanNumeral value
            romanNumeral = "";

            //Reset context and expression tree 
            rnContext = null;
            rnExpressionTree = null;
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            // Exit Button Click Event Handler
            // This will handle any clicks of the Exit button
            ExitApplication();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            // Reset Button Click Event Handler
            // Call the ResetForm() procedure
            ResetForm();
        }

        private void BtnConvert_Click(object sender, EventArgs e)
        {
            // Take Roman Numeral input and store it
            romanNumeral = txtInput.Text.Trim();

            // Pass romanNumeral input to a new context
            rnContext = new Context(romanNumeral);

            // Create a new expression tree
            rnExpressionTree = new List<Expression>();

            // Add Roman Numeral Expressions to the expression tree
            rnExpressionTree.Add(new ThousandExpression());
            rnExpressionTree.Add(new HundredsExpression());
            rnExpressionTree.Add(new TenExpression());
            rnExpressionTree.Add(new OneExpression());

            // Interpret the roman numeral by iterating
            // through each expression in the ExpressionTree
            foreach (Expression exp in rnExpressionTree)
            {
                exp.Interpret(rnContext);
            }

            // Display converted number
            lblOutput.Text = rnContext.Output.ToString();
        }
    }
}
    

