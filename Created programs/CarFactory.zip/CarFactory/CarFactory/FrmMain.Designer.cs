﻿
namespace CarFactory
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PnlBuild = new System.Windows.Forms.Panel();
            this.LblFormTitle = new System.Windows.Forms.Label();
            this.LblFormCaption = new System.Windows.Forms.Label();
            this.LblVehicleSelection = new System.Windows.Forms.Label();
            this.LblHatch = new System.Windows.Forms.Label();
            this.LblSaloon = new System.Windows.Forms.Label();
            this.Lbl4x4 = new System.Windows.Forms.Label();
            this.LblSports = new System.Windows.Forms.Label();
            this.LblEV = new System.Windows.Forms.Label();
            this.BtnBuild = new System.Windows.Forms.Button();
            this.BtnReset = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.LblBuild = new System.Windows.Forms.Label();
            this.LblDoors = new System.Windows.Forms.Label();
            this.LblTransmission = new System.Windows.Forms.Label();
            this.LblEngine = new System.Windows.Forms.Label();
            this.LblDoorsD = new System.Windows.Forms.Label();
            this.LblTransmissionD = new System.Windows.Forms.Label();
            this.LblEngineD = new System.Windows.Forms.Label();
            this.LblFuel = new System.Windows.Forms.Label();
            this.LblDrivetrain = new System.Windows.Forms.Label();
            this.LblColour = new System.Windows.Forms.Label();
            this.LblFuelD = new System.Windows.Forms.Label();
            this.LblDrivetrainD = new System.Windows.Forms.Label();
            this.LblColourD = new System.Windows.Forms.Label();
            this.RbEV = new System.Windows.Forms.RadioButton();
            this.RbSports = new System.Windows.Forms.RadioButton();
            this.Rb4x4 = new System.Windows.Forms.RadioButton();
            this.RbSaloon = new System.Windows.Forms.RadioButton();
            this.RbHatch = new System.Windows.Forms.RadioButton();
            this.PicCar = new System.Windows.Forms.PictureBox();
            this.PnlBuild.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicCar)).BeginInit();
            this.SuspendLayout();
            // 
            // PnlBuild
            // 
            this.PnlBuild.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlBuild.Controls.Add(this.LblColourD);
            this.PnlBuild.Controls.Add(this.LblDrivetrainD);
            this.PnlBuild.Controls.Add(this.LblFuelD);
            this.PnlBuild.Controls.Add(this.LblColour);
            this.PnlBuild.Controls.Add(this.LblDrivetrain);
            this.PnlBuild.Controls.Add(this.LblFuel);
            this.PnlBuild.Controls.Add(this.LblEngineD);
            this.PnlBuild.Controls.Add(this.LblTransmissionD);
            this.PnlBuild.Controls.Add(this.LblDoorsD);
            this.PnlBuild.Controls.Add(this.LblEngine);
            this.PnlBuild.Controls.Add(this.LblTransmission);
            this.PnlBuild.Controls.Add(this.LblDoors);
            this.PnlBuild.Controls.Add(this.LblBuild);
            this.PnlBuild.Controls.Add(this.PicCar);
            this.PnlBuild.Location = new System.Drawing.Point(12, 358);
            this.PnlBuild.Name = "PnlBuild";
            this.PnlBuild.Size = new System.Drawing.Size(778, 207);
            this.PnlBuild.TabIndex = 0;
            // 
            // LblFormTitle
            // 
            this.LblFormTitle.BackColor = System.Drawing.Color.SteelBlue;
            this.LblFormTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblFormTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFormTitle.ForeColor = System.Drawing.Color.White;
            this.LblFormTitle.Location = new System.Drawing.Point(0, 0);
            this.LblFormTitle.Name = "LblFormTitle";
            this.LblFormTitle.Size = new System.Drawing.Size(1060, 38);
            this.LblFormTitle.TabIndex = 1;
            this.LblFormTitle.Text = "SERC Vehicle Factory";
            this.LblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblFormCaption
            // 
            this.LblFormCaption.AutoSize = true;
            this.LblFormCaption.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFormCaption.Location = new System.Drawing.Point(289, 78);
            this.LblFormCaption.Name = "LblFormCaption";
            this.LblFormCaption.Size = new System.Drawing.Size(501, 55);
            this.LblFormCaption.TabIndex = 2;
            this.LblFormCaption.Text = "SERC Vehicle Factory";
            // 
            // LblVehicleSelection
            // 
            this.LblVehicleSelection.AutoSize = true;
            this.LblVehicleSelection.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblVehicleSelection.Location = new System.Drawing.Point(50, 148);
            this.LblVehicleSelection.Name = "LblVehicleSelection";
            this.LblVehicleSelection.Size = new System.Drawing.Size(173, 29);
            this.LblVehicleSelection.TabIndex = 3;
            this.LblVehicleSelection.Text = "Select Vehicle:";
            // 
            // LblHatch
            // 
            this.LblHatch.AutoSize = true;
            this.LblHatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHatch.Location = new System.Drawing.Point(84, 315);
            this.LblHatch.Name = "LblHatch";
            this.LblHatch.Size = new System.Drawing.Size(79, 18);
            this.LblHatch.TabIndex = 9;
            this.LblHatch.Text = "Hatchback";
            // 
            // LblSaloon
            // 
            this.LblSaloon.AutoSize = true;
            this.LblSaloon.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSaloon.Location = new System.Drawing.Point(307, 315);
            this.LblSaloon.Name = "LblSaloon";
            this.LblSaloon.Size = new System.Drawing.Size(55, 18);
            this.LblSaloon.TabIndex = 10;
            this.LblSaloon.Text = "Saloon";
            // 
            // Lbl4x4
            // 
            this.Lbl4x4.AutoSize = true;
            this.Lbl4x4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl4x4.Location = new System.Drawing.Point(516, 315);
            this.Lbl4x4.Name = "Lbl4x4";
            this.Lbl4x4.Size = new System.Drawing.Size(31, 18);
            this.Lbl4x4.TabIndex = 11;
            this.Lbl4x4.Text = "4x4";
            // 
            // LblSports
            // 
            this.LblSports.AutoSize = true;
            this.LblSports.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSports.Location = new System.Drawing.Point(710, 315);
            this.LblSports.Name = "LblSports";
            this.LblSports.Size = new System.Drawing.Size(52, 18);
            this.LblSports.TabIndex = 12;
            this.LblSports.Text = "Sports";
            // 
            // LblEV
            // 
            this.LblEV.AutoSize = true;
            this.LblEV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEV.Location = new System.Drawing.Point(930, 315);
            this.LblEV.Name = "LblEV";
            this.LblEV.Size = new System.Drawing.Size(27, 18);
            this.LblEV.TabIndex = 13;
            this.LblEV.Text = "EV";
            // 
            // BtnBuild
            // 
            this.BtnBuild.BackColor = System.Drawing.Color.Yellow;
            this.BtnBuild.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBuild.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBuild.Location = new System.Drawing.Point(812, 358);
            this.BtnBuild.Name = "BtnBuild";
            this.BtnBuild.Size = new System.Drawing.Size(231, 65);
            this.BtnBuild.TabIndex = 14;
            this.BtnBuild.Text = "Build";
            this.BtnBuild.UseVisualStyleBackColor = false;
            // 
            // BtnReset
            // 
            this.BtnReset.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReset.Location = new System.Drawing.Point(812, 429);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.Size = new System.Drawing.Size(231, 65);
            this.BtnReset.TabIndex = 15;
            this.BtnReset.Text = "Reset";
            this.BtnReset.UseVisualStyleBackColor = false;
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.Firebrick;
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(812, 500);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(231, 65);
            this.BtnExit.TabIndex = 16;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // LblBuild
            // 
            this.LblBuild.AutoSize = true;
            this.LblBuild.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBuild.Location = new System.Drawing.Point(311, 7);
            this.LblBuild.Name = "LblBuild";
            this.LblBuild.Size = new System.Drawing.Size(178, 31);
            this.LblBuild.TabIndex = 1;
            this.LblBuild.Text = "Vehicle Build:";
            // 
            // LblDoors
            // 
            this.LblDoors.AutoSize = true;
            this.LblDoors.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDoors.Location = new System.Drawing.Point(314, 60);
            this.LblDoors.Name = "LblDoors";
            this.LblDoors.Size = new System.Drawing.Size(50, 18);
            this.LblDoors.TabIndex = 2;
            this.LblDoors.Text = "Doors";
            // 
            // LblTransmission
            // 
            this.LblTransmission.AutoSize = true;
            this.LblTransmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTransmission.Location = new System.Drawing.Point(314, 105);
            this.LblTransmission.Name = "LblTransmission";
            this.LblTransmission.Size = new System.Drawing.Size(98, 18);
            this.LblTransmission.TabIndex = 3;
            this.LblTransmission.Text = "Transmission";
            // 
            // LblEngine
            // 
            this.LblEngine.AutoSize = true;
            this.LblEngine.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEngine.Location = new System.Drawing.Point(314, 152);
            this.LblEngine.Name = "LblEngine";
            this.LblEngine.Size = new System.Drawing.Size(86, 18);
            this.LblEngine.TabIndex = 4;
            this.LblEngine.Text = "Engine Size";
            // 
            // LblDoorsD
            // 
            this.LblDoorsD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblDoorsD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDoorsD.Location = new System.Drawing.Point(418, 54);
            this.LblDoorsD.Name = "LblDoorsD";
            this.LblDoorsD.Size = new System.Drawing.Size(100, 30);
            this.LblDoorsD.TabIndex = 5;
            this.LblDoorsD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblTransmissionD
            // 
            this.LblTransmissionD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblTransmissionD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTransmissionD.Location = new System.Drawing.Point(418, 99);
            this.LblTransmissionD.Name = "LblTransmissionD";
            this.LblTransmissionD.Size = new System.Drawing.Size(100, 30);
            this.LblTransmissionD.TabIndex = 6;
            this.LblTransmissionD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblEngineD
            // 
            this.LblEngineD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblEngineD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEngineD.Location = new System.Drawing.Point(418, 146);
            this.LblEngineD.Name = "LblEngineD";
            this.LblEngineD.Size = new System.Drawing.Size(100, 30);
            this.LblEngineD.TabIndex = 7;
            this.LblEngineD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblFuel
            // 
            this.LblFuel.AutoSize = true;
            this.LblFuel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFuel.Location = new System.Drawing.Point(560, 60);
            this.LblFuel.Name = "LblFuel";
            this.LblFuel.Size = new System.Drawing.Size(72, 18);
            this.LblFuel.TabIndex = 8;
            this.LblFuel.Text = "Fuel Type";
            // 
            // LblDrivetrain
            // 
            this.LblDrivetrain.AutoSize = true;
            this.LblDrivetrain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDrivetrain.Location = new System.Drawing.Point(560, 105);
            this.LblDrivetrain.Name = "LblDrivetrain";
            this.LblDrivetrain.Size = new System.Drawing.Size(70, 18);
            this.LblDrivetrain.TabIndex = 9;
            this.LblDrivetrain.Text = "Drivetrain";
            // 
            // LblColour
            // 
            this.LblColour.AutoSize = true;
            this.LblColour.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblColour.Location = new System.Drawing.Point(560, 152);
            this.LblColour.Name = "LblColour";
            this.LblColour.Size = new System.Drawing.Size(53, 18);
            this.LblColour.TabIndex = 10;
            this.LblColour.Text = "Colour";
            // 
            // LblFuelD
            // 
            this.LblFuelD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblFuelD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFuelD.Location = new System.Drawing.Point(638, 54);
            this.LblFuelD.Name = "LblFuelD";
            this.LblFuelD.Size = new System.Drawing.Size(100, 30);
            this.LblFuelD.TabIndex = 11;
            this.LblFuelD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblDrivetrainD
            // 
            this.LblDrivetrainD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblDrivetrainD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDrivetrainD.Location = new System.Drawing.Point(638, 99);
            this.LblDrivetrainD.Name = "LblDrivetrainD";
            this.LblDrivetrainD.Size = new System.Drawing.Size(100, 30);
            this.LblDrivetrainD.TabIndex = 12;
            this.LblDrivetrainD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblColourD
            // 
            this.LblColourD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblColourD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblColourD.Location = new System.Drawing.Point(638, 146);
            this.LblColourD.Name = "LblColourD";
            this.LblColourD.Size = new System.Drawing.Size(100, 30);
            this.LblColourD.TabIndex = 13;
            this.LblColourD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RbEV
            // 
            this.RbEV.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbEV.BackgroundImage = global::CarFactory.Properties.Resources.ev;
            this.RbEV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RbEV.FlatAppearance.BorderSize = 0;
            this.RbEV.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.RbEV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RbEV.Location = new System.Drawing.Point(843, 212);
            this.RbEV.Name = "RbEV";
            this.RbEV.Size = new System.Drawing.Size(200, 100);
            this.RbEV.TabIndex = 8;
            this.RbEV.TabStop = true;
            this.RbEV.UseVisualStyleBackColor = true;
            // 
            // RbSports
            // 
            this.RbSports.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbSports.BackgroundImage = global::CarFactory.Properties.Resources.sport;
            this.RbSports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RbSports.FlatAppearance.BorderSize = 0;
            this.RbSports.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.RbSports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RbSports.Location = new System.Drawing.Point(638, 212);
            this.RbSports.Name = "RbSports";
            this.RbSports.Size = new System.Drawing.Size(200, 100);
            this.RbSports.TabIndex = 7;
            this.RbSports.TabStop = true;
            this.RbSports.UseVisualStyleBackColor = true;
            // 
            // Rb4x4
            // 
            this.Rb4x4.Appearance = System.Windows.Forms.Appearance.Button;
            this.Rb4x4.BackgroundImage = global::CarFactory.Properties.Resources._4x4;
            this.Rb4x4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Rb4x4.FlatAppearance.BorderSize = 0;
            this.Rb4x4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.Rb4x4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Rb4x4.Location = new System.Drawing.Point(433, 212);
            this.Rb4x4.Name = "Rb4x4";
            this.Rb4x4.Size = new System.Drawing.Size(200, 100);
            this.Rb4x4.TabIndex = 6;
            this.Rb4x4.TabStop = true;
            this.Rb4x4.UseVisualStyleBackColor = true;
            // 
            // RbSaloon
            // 
            this.RbSaloon.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbSaloon.BackgroundImage = global::CarFactory.Properties.Resources.saloon;
            this.RbSaloon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RbSaloon.FlatAppearance.BorderSize = 0;
            this.RbSaloon.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.RbSaloon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RbSaloon.Location = new System.Drawing.Point(228, 212);
            this.RbSaloon.Name = "RbSaloon";
            this.RbSaloon.Size = new System.Drawing.Size(200, 100);
            this.RbSaloon.TabIndex = 5;
            this.RbSaloon.TabStop = true;
            this.RbSaloon.UseVisualStyleBackColor = true;
            // 
            // RbHatch
            // 
            this.RbHatch.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbHatch.BackgroundImage = global::CarFactory.Properties.Resources.hatch;
            this.RbHatch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RbHatch.FlatAppearance.BorderSize = 0;
            this.RbHatch.FlatAppearance.CheckedBackColor = System.Drawing.Color.Yellow;
            this.RbHatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RbHatch.Location = new System.Drawing.Point(23, 212);
            this.RbHatch.Name = "RbHatch";
            this.RbHatch.Size = new System.Drawing.Size(200, 100);
            this.RbHatch.TabIndex = 4;
            this.RbHatch.TabStop = true;
            this.RbHatch.UseVisualStyleBackColor = true;
            // 
            // PicCar
            // 
            this.PicCar.Location = new System.Drawing.Point(24, 54);
            this.PicCar.Name = "PicCar";
            this.PicCar.Size = new System.Drawing.Size(256, 122);
            this.PicCar.TabIndex = 0;
            this.PicCar.TabStop = false;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(1060, 580);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnReset);
            this.Controls.Add(this.BtnBuild);
            this.Controls.Add(this.LblEV);
            this.Controls.Add(this.LblSports);
            this.Controls.Add(this.Lbl4x4);
            this.Controls.Add(this.LblSaloon);
            this.Controls.Add(this.LblHatch);
            this.Controls.Add(this.RbEV);
            this.Controls.Add(this.RbSports);
            this.Controls.Add(this.Rb4x4);
            this.Controls.Add(this.RbSaloon);
            this.Controls.Add(this.RbHatch);
            this.Controls.Add(this.LblVehicleSelection);
            this.Controls.Add(this.LblFormCaption);
            this.Controls.Add(this.LblFormTitle);
            this.Controls.Add(this.PnlBuild);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.PnlBuild.ResumeLayout(false);
            this.PnlBuild.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicCar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PnlBuild;
        private System.Windows.Forms.Label LblColourD;
        private System.Windows.Forms.Label LblDrivetrainD;
        private System.Windows.Forms.Label LblFuelD;
        private System.Windows.Forms.Label LblColour;
        private System.Windows.Forms.Label LblDrivetrain;
        private System.Windows.Forms.Label LblFuel;
        private System.Windows.Forms.Label LblEngineD;
        private System.Windows.Forms.Label LblTransmissionD;
        private System.Windows.Forms.Label LblDoorsD;
        private System.Windows.Forms.Label LblEngine;
        private System.Windows.Forms.Label LblTransmission;
        private System.Windows.Forms.Label LblDoors;
        private System.Windows.Forms.Label LblBuild;
        private System.Windows.Forms.PictureBox PicCar;
        private System.Windows.Forms.Label LblFormTitle;
        private System.Windows.Forms.Label LblFormCaption;
        private System.Windows.Forms.Label LblVehicleSelection;
        private System.Windows.Forms.RadioButton RbHatch;
        private System.Windows.Forms.RadioButton RbSaloon;
        private System.Windows.Forms.RadioButton Rb4x4;
        private System.Windows.Forms.RadioButton RbSports;
        private System.Windows.Forms.RadioButton RbEV;
        private System.Windows.Forms.Label LblHatch;
        private System.Windows.Forms.Label LblSaloon;
        private System.Windows.Forms.Label Lbl4x4;
        private System.Windows.Forms.Label LblSports;
        private System.Windows.Forms.Label LblEV;
        private System.Windows.Forms.Button BtnBuild;
        private System.Windows.Forms.Button BtnReset;
        private System.Windows.Forms.Button BtnExit;
    }
}

