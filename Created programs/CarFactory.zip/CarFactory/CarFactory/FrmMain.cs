﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarFactory
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void Exit()
        {
            // Procedure to exit application
            DialogResult userResponse =
                MessageBox.Show("Are you sure you want to exit?",
                "Exit application?", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            // Evaluate user's response
            if(userResponse.Equals(DialogResult.Yes))
            {
                // Exit application if user clicked yes
                Application.Exit();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            // Call the exit procedure
            Exit();
        }
    }
}
